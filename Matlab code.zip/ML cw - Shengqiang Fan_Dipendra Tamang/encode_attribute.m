function [ encoded ] = encode_attribute( raw )
%input: categorical attributes
%output: numerical data
encoded = zeros(1, 6);
% 1st attribute - buying: vhigh, high, med, low to 1, 2, 3, 4 respectively.
switch raw {1}
    case 'vhigh'
        encoded (1)= 1;
    case 'high'
        encoded(1) = 2;
    case 'med'
        encoded(1)= 3;
    case 'low'
        encoded(1) = 4;
end
% 2ed atrribute - maint: vhigh, high, med, low to number 1, 2, 3, 4 respectively.
switch raw{2}
    case 'vhigh'
        encoded(2) = 1;
    case 'high'
        encoded(2) = 2;
    case 'med'
        encoded(2) = 3;
    case 'low'
        encoded(2) = 4;
end
% 3rd attribute - doors: 2, 3, 4, 5more to number 1, 2, 3,4 respectively.
switch raw{3}
    case '2'
        encoded(3) = 1;
    case '3'
        encoded(3) = 2;
    case '4'
        encoded(3) = 3;
    case '5more'
        encoded(3) = 4;
end
% 4th attribute - persons: 2, 4, more to number 1, 1, 3 respectively.
switch raw{4}
    case '2'
        encoded(4) = 1;
    case '4'
        encoded(4) = 2;
    case 'more'
        encoded(4) = 3;
end

% 5th attribute - lug_boot: small, med, big to number 1, 2, 3 respectively.
switch raw{5}
    case 'small'
        encoded(5) = 1;
    case 'med'
        encoded(5) = 2;
    case 'big'
        encoded(5) = 3;
end
% 6th attribute - safety: low, med, high to number 1, 2, 3 respectively.
switch raw{6}
    case 'low'
        encoded(6) = 1;
    case 'med'
        encoded(6) = 2;
    case 'high'
        encoded(6) = 3;
end
end

