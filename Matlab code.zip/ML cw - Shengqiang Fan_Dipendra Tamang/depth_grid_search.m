function [depth_againt_error] = depth_grid_search(depth, train_data, train_label)
%input: depth of trees
%output: cross valiation error versus increasing depth of trees
splits = depth;
rng('default')
N = numel(splits);
err = zeros(N,1);
for n=1:N
    t = fitctree(train_data, train_label,'CrossVal','On',...
        'MaxNumSplits',splits(n));
    err(n) = kfoldLoss(t);
end
figure(3)
plot(splits,err);
xlabel('MaxNumSplits');
ylabel('cross-validated error');
end