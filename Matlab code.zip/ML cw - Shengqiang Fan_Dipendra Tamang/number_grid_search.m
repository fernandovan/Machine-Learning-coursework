function [numbers_againt_error] = number_grid_search(number, train_data, train_label)
%input: number of trees/train data&label
%output: Out of bag classification error versus increasing number of trees
B = TreeBagger(number,train_data,train_label,'OOBPrediction','On', 'Method', 'classification');
oobErrorBaggedEnsemble = oobError(B);
figure(4);
plot(oobErrorBaggedEnsemble)
xlabel 'Number of grown trees';
ylabel 'Out-of-bag classification error';
end