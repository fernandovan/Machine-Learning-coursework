function [data,label] = encodeData(d)
length = size(d,1);
data = [];
label = zeros(length,1);
for i = 1:length
    temp = strsplit(d{i} , ",");
    data(i, :) = encode_attribute(temp(1:6));
    label(i) = encode_label(temp{7});
    end
end

