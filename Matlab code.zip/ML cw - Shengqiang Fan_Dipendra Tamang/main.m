clear;
clc;
%Import the data
orig_data = importdata('car.data');
[data, label] = encodeData(orig_data);
[train_data,train_label,test_data,test_label] = split_test_train(data,label);
%%
% Exploratory data
labelProbability=tabulate(train_label);
speci_label = labelProbability(:,1);
num_label = labelProbability(:,2);
figure(1);
bar(speci_label,num_label)
set(gca,'XTick',1:2:3:4);
set(gca,'XTickLabel',{'unacc','acc','good','vgood'});
title("Distribution of 4 class types")
%train data has is positive skewed, may influence the accuracy of classification
corr=corrcoef(train_data);
figure(2);
heatmap(corr)
ax = gca;
ax.XData = ["Buying" "Maint" "Doors" "Persons" "Lug_boot" "Safety"];
ax.YData = ["Buying" "Maint" "Doors" "Persons" "Lug_boot" "Safety"];
title("Correlation matrix of 6 attributes");
%figure shows no correration between 6 variables
%%
%Random Forest
%grid_search for depth of tress
depth_grid_search(logspace(1,2,20), train_data, train_label)
%grid search for number of trees
number_grid_search(100, train_data, train_label)
%grid search for number of attributes per slipt
nattributes = 1:6;
attributes_grid_search(nattributes, train_data, train_label)
%Based on grid search, each hyperparameter is found, hence make predictions under 
%depth=50, number of trees=50, number of attributes per slipt=4
[accuracy_random_test, predictedClass] = RandomForest(50,50,4,train_data,train_label,test_data,test_label);
accuracy_random_test
%%
%KNN
[accuracy_k] = knn_cross_vali(train_data,train_label);
%using plot to find hyper parameter k--- k=4-8 would be better.
knnacc_cross_vali = accuracy_k(5)
%then use k=5
Mdl = fitcknn(train_data,train_label,'NumNeighbors',5,'Standardize',1);
knnlabel_nox = predict(Mdl,test_data);
knnacc_test = mean(knnlabel_nox == test_label)
%drop "Buying" 
drop_xattribute([2:6],train_data,train_label,test_data,test_label);
%drop "Maint"  
drop_xattribute([1,3:6],train_data,train_label,test_data,test_label);
%drop "Doors" 
drop_xattribute([1:2,4:6],train_data,train_label,test_data,test_label);
%drop "Persons"
drop_xattribute([1:3,5:6],train_data,train_label,test_data,test_label);
%drop "Lug_boot"
drop_xattribute([1:4,6],train_data,train_label,test_data,test_label);
%drop "Safety"
drop_xattribute([1:5],train_data,train_label,test_data,test_label);

%%
% Report the result confusion matrix
figure(8);
confusionMatrix(test_label,predictedClass)
title('Random Forest Confusion Matrix');
figure(9);
confusionMatrix(test_label,knnlabel_nox)
title('KNN Confusion Matrix');



