function [depth_againt_error] = attributes_grid_search(nattributes, train_data, train_label)
%input: number of attributes per split/train data/train label
%output: cross validation error versus increasing number of attributes
attributes = nattributes;
rng('default')
N = numel(attributes);
err = zeros(N,1);
for n=1:N
    t = fitctree(train_data, train_label,'CrossVal','On',...
        'NumPredictorsToSample',attributes(n));
    err(n) = kfoldLoss(t);
end
figure(5)
plot(attributes,err);
xlabel('Number of attributes per split');
ylabel('cross-validated error');
end