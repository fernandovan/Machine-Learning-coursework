function [encoded] = encode_label(raw)
%input categorical labels
%numerical labels
%unacc, acc, good, vgood to 1, 2, 3, 4 respectively.
switch raw
    case "unacc"
        encoded = 1;
    case 'acc'
        encoded = 2;
    case 'good'
        encoded = 3;
    case 'vgood'
        encoded = 4;
end   
end

