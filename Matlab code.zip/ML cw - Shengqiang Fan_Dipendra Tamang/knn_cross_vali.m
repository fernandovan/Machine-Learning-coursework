function [accuracy_k] = knn_cross_vali(train_data,train_label)
%input: train data &label for knn
%output: cross validation accuracy
accuracy_result=[];
indices = crossvalind('Kfold', train_label, 10);
for k =1:20
    for i = 1 : 10
        test = (indices == i);
        train = ~test;
        test_data_cross = train_data(test,:);
        test_label_cross = train_label(test,:);
        train_data_cross = train_data(train,:);
        train_label_cross = train_label(train,:);
        Mdl = fitcknn(train_data_cross,train_label_cross,'NumNeighbors',k,'Standardize',1);
        knnlabel = predict(Mdl,test_data_cross);
        accuracy_result = [accuracy_result,mean(knnlabel == test_label_cross)];
    end
end

j = 0;
accuracy_k = [];
for i = 0 : 10 : size(accuracy_result,2)-10
    j = j + 1;
    accuracy_k = [accuracy_k,mean(accuracy_result(i+1:i+10))];
end
accuracy_k;
figure(7);
x_axis = 1:20;
plot(x_axis,accuracy_k);
xlabel('Value of K for KNN')
ylabel('Cross-Validated Accuracy')
end

