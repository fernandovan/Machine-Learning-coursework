function [accuracy_random_test, predictedClass] = RandomForest(ntrees,depth,nattributes,train_data, train_label, test_data, test_label)
%input: number of trees/depth of tree/number of attributes per split/train data&label/test data&label
%output: test set accuracy/graph of one typical dicision tree in random forest
nTrees = ntrees;
% Train the TreeBagger
B = TreeBagger(nTrees,train_data,train_label,'OOBPrediction','On', 'Method', 'classification','PredictorSelection','curvature','OOBPredictorImportance','on','MaxNumSplits',depth,'NumPredictorsToSample',nattributes);
newData1 = test_data;
% Use the trained Decision Forest.
predChar1 = B.predict(newData1);
% Transform char to number.
predictedClass = str2double(predChar1);
accuracy_random_test = mean(predictedClass == test_label);
view(B.Trees{1},'Mode','graph')
imp = B.OOBPermutedPredictorDeltaError;
figure(6);
bar(imp);
title('Importance of attributes - curvature test');
ylabel('Predictor importance estimates');
xlabel('Predictors');
h = gca;
h.XTickLabel = ["Buying" "Maint" "Doors" "Persons" "Lug_boot" "Safety"];
h.XTickLabelRotation = 45;
h.TickLabelInterpreter = 'none';
end
