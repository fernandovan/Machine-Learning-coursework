function confusionMatrix(act1,det1)
 %in put: accuracy matrix
 %output: visual graph of confusion matrix
[mat,order] = confusionmat(act1,det1);
k=max(order);
imagesc(mat); % Create a colored plot of the matrix values
colormap(flipud(gray));  %black and lower values are white)
textStrings = num2str(mat(:),'%0.02f');       
textStrings = strtrim(cellstr(textStrings));  
 
%%
[x,y] = meshgrid(1:k); 
hStrings=text(x(:),y(:),textStrings(:),'HorizontalAlignment','center');
midValue = mean(get(gca,'CLim')); 
textColors = repmat(mat(:) > midValue,1,3);  
set(hStrings,{'Color'},num2cell(textColors,2));

set(gca,'XTick',1:4,...                                   
        'XTickLabel',{'unacc','acc','good','vgood'},...  
        'YTick',1:4,...                                    
        'YTickLabel',{'unacc','acc','good','vgood'},...
        'TickLength',[0 0]);
end
