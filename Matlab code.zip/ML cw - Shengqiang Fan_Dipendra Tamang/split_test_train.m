function [train_data, train_label, test_data, test_label] = split_test_train(data,label)
%input: original train data&label
%output: 70% as train data/30% as test data
n = size(data,1);
k = floor(n*0.7);
indices = randsample(n,k);
for i = 1:k
    train_data(i,:)=data(indices(i),:);
    train_label(i,1)=label(indices(i),1);
end
l=1;
for i = 1:n
    if (~ismember(i,indices))
        test_data(l,:)=data(i,:);
        test_label(l,1)=label(i,1);
            l=l+1;
    end
end
end

