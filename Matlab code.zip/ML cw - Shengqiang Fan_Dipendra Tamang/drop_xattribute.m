function [accuracy_drop_x] = drop_xattribute(remian_attribute,train_data,train_label,test_data,test_label)
%input: remaining attributes/train data&label/test data&label
%output: test set accuracy for different dropping attribute case
train_data_drop_x = train_data(:,remian_attribute);
Mdl_1 = fitcknn(train_data_drop_x,train_label,'NumNeighbors',5,'Standardize',1);
test_data_dropbuying = test_data(:,remian_attribute);
knnlabel_nox = predict(Mdl_1,test_data_dropbuying);
knnacc_accuracy_dropx = mean(knnlabel_nox == test_label)
end
